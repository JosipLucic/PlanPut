INSERT INTO Autoprijevoznik (naziv) 
VALUES ('Arriva');

INSERT INTO Autoprijevoznik (naziv) 
VALUES ('Croatia Bus');



INSERT INTO Vozilo (regTablica, idAutoprijevoznik, brojMjesta, tipVozila)
VALUES ('ABC123', 1, 20, 'autobus');

INSERT INTO Vozilo (regTablica, idAutoprijevoznik, brojMjesta, tipVozila)
VALUES ('AKL173', 1, 30, 'autobus');

INSERT INTO Vozilo (regTablica, idAutoprijevoznik, brojMjesta, tipVozila)
VALUES ('XYZ789', 2, 30, 'minibus');



INSERT INTO Mjesto (pbr, naziv) 
VALUES (10000, 'Zagreb');

INSERT INTO Mjesto (pbr, naziv) 
VALUES (21000, 'Split');

INSERT INTO Mjesto (pbr, naziv)
VALUES (51000, 'Rijeka');

INSERT INTO Mjesto (pbr, naziv)
VALUES (23000, 'Zadar');

INSERT INTO Mjesto (pbr, naziv)
VALUES (35000, 'Slavonski Brod');

INSERT INTO Mjesto (pbr, naziv) 
VALUES (10410, 'Velika Gorica');

INSERT INTO Mjesto (pbr, naziv)
VALUES (47000, 'Karlovac');

INSERT INTO Mjesto (pbr, naziv)
VALUES (52100, 'Pula');

INSERT INTO Mjesto (pbr, naziv)
VALUES (20000, 'Dubrovnik');

INSERT INTO Mjesto (pbr, naziv)
VALUES (22000, 'Šibenik');

INSERT INTO Mjesto (pbr, naziv)
VALUES (52440, 'Poreč');

INSERT INTO Mjesto (pbr, naziv)
VALUES (51410, 'Opatija');

INSERT INTO Mjesto (pbr, naziv)
VALUES (31000, 'Osijek');

INSERT INTO Mjesto (pbr, naziv)
VALUES (21300, 'Makarska');

INSERT INTO Mjesto (pbr, naziv)
VALUES (21210, 'Solin');

INSERT INTO Mjesto (pbr, naziv)
VALUES (43000, 'Bjelovar');



INSERT INTO Ponuda (vrijemePolaska, vrijemeDolaska, mjestoPolaska, mjestoDolaska, cijena, idAutoprijevoznik)
VALUES ('2024-07-20 08:00:00', '2024-07-20 12:00:00', 10000, 21000, 100.00, 1);

INSERT INTO Ponuda (vrijemePolaska, vrijemeDolaska, mjestoPolaska, mjestoDolaska, cijena, idAutoprijevoznik)
VALUES ('2024-06-15 10:00:00', '2024-06-15 14:00:00', 21000, 10000, 80.00, 1);

INSERT INTO Ponuda (vrijemePolaska, vrijemeDolaska, mjestoPolaska, mjestoDolaska, cijena, idAutoprijevoznik)
VALUES ('2024-05-20 08:00:00', '2024-05-20 12:00:00', 43000, 21000, 50.00, 2);



INSERT INTO PonudaVozilo (idPonuda, idVozilo, brojKarata)
VALUES (1, 1, 20);

INSERT INTO PonudaVozilo (idPonuda, idVozilo, brojKarata)
VALUES (1, 2, 30);

INSERT INTO PonudaVozilo (idPonuda, idVozilo, brojKarata)
VALUES (2, 2, 30);

INSERT INTO PonudaVozilo (idPonuda, idVozilo, brojKarata)
VALUES (3, 3, 30);