package planput.c_repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.OverrideAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import planput.d_domain.*;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import static org.assertj.core.api.Assertions.*;

@DataJpaTest
public class RepositoryUnitTests {
    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private PonudaRepo ponudaRepo;

    @Autowired
    private VoziloRepo voziloRepo;

    @Autowired
    private MjestoRepo mjestoRepo;

    @Autowired
    private AutoprijevoznikRepo autoprijevoznikRepo;

    @Test
    public void findDostupne() {

        Ponuda ponuda1 = new Ponuda(
                new Timestamp(System.currentTimeMillis() - 18_000_000),
                new Timestamp(System.currentTimeMillis() - 10_000_000),
                null,
                null,
                100,
                null,
                null
        );
        Ponuda ponuda2 = new Ponuda(
                new Timestamp(System.currentTimeMillis() + 10_000_000),
                new Timestamp(System.currentTimeMillis() + 18_000_000),
                null,
                null,
                100,
                null,
                null
        );
        Ponuda ponuda3 = new Ponuda(
                new Timestamp(System.currentTimeMillis() + 10_000_000),
                new Timestamp(System.currentTimeMillis() + 18_000_000),
                null,
                null,
                100,
                null,
                null
        );

        entityManager.persist(ponuda1);
        entityManager.persist(ponuda2);
        entityManager.persist(ponuda3);

        List<Ponuda> ponude = ponudaRepo.findDostupne(new Timestamp(System.currentTimeMillis()));
        assertThat(ponude.size()).isEqualTo(2);
    }

    @Test
    public void findByRegTablicaTest() {
        Vozilo vozilo = new Vozilo("ABC123", 4, "SUV");
        entityManager.persist(vozilo);

        Optional<Vozilo> vozilo1 = voziloRepo.findByRegTablica("ABC123");
        assertThat(vozilo1.isPresent()).isTrue();
        assertThat(vozilo1.get()).extracting("regTablica").isEqualTo("ABC123");

        Optional<Vozilo> vozilo2 = voziloRepo.findByRegTablica("NepostojecaTablica");
        assertThat(vozilo2.isPresent()).isFalse();
    }

    @Test
    public void findByNazivMjesto() {
        Mjesto mjesto = new Mjesto(21000, "Split");
        entityManager.persist(mjesto);

        Optional<Mjesto> mjesto1 = mjestoRepo.findByNaziv("Split");
        assertThat(mjesto1.isPresent()).isTrue();
        assertThat(mjesto1.get()).extracting("naziv").isEqualTo("Split");

        Optional<Mjesto> mjesto2 = mjestoRepo.findByNaziv("NepostojeceMjesto");
        assertThat(mjesto2.isPresent()).isFalse();
    }

    @Test
    public void findByNazivAutoprijevoznikTest() {
        Autoprijevoznik autoprijevoznik = new Autoprijevoznik("Arriva", List.of(new Vozilo("ABC123", 4, "SUV")));
        entityManager.persist(autoprijevoznik);

        Optional<Autoprijevoznik> autoprijevoznik1 = autoprijevoznikRepo.findByNaziv("Arriva");
        assertThat(autoprijevoznik1.isPresent()).isTrue();
        assertThat(autoprijevoznik1.get()).extracting("naziv").isEqualTo("Arriva");

        Optional<Mjesto> autoprijevoznik2 = mjestoRepo.findByNaziv("NepostojeceMjesto");
        assertThat(autoprijevoznik2.isPresent()).isFalse();
    }

}
