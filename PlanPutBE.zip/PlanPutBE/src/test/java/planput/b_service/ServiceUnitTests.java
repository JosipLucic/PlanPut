package planput.b_service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import planput.a_controller.DTO.NoviAutoprijevoznikDTO;
import planput.c_repository.AutoprijevoznikRepo;
import planput.c_repository.PonudaRepo;
import planput.c_repository.PonudaVoziloRepo;
import planput.c_repository.VoziloRepo;
import planput.d_domain.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ServiceUnitTests {

    @InjectMocks
    private CRUDService service;

    @Mock
    private PonudaRepo ponudaRepo;

    @Mock
    private AutoprijevoznikRepo autoprijevoznikRepo;

    @Mock
    private PonudaVoziloRepo pvRepo;

    @Mock
    private VoziloRepo voziloRepo;

    @Test
    void canDohvatiPonude() {
        // Given
        List<Ponuda> expectedPonude = Collections.singletonList(new Ponuda());
        when(ponudaRepo.findDostupne(any(Timestamp.class))).thenReturn(expectedPonude);
        // When
        List<Ponuda> actualPonude = service.dohvatiPonude();
        // Then
        verify(ponudaRepo).findDostupne(any(Timestamp.class));
        assertEquals(expectedPonude, actualPonude);
    }

    @Test
    void canDohvatiPonuduById() {
        // Given
        long idPonuda = 1L;
        Ponuda expectedPonuda = new Ponuda();
        when(ponudaRepo.findById(idPonuda)).thenReturn(Optional.of(expectedPonuda));
        // When
        Ponuda actualPonuda = service.dohvatiPonudu(idPonuda);
        // Then
        verify(ponudaRepo).findById(idPonuda);
        assertEquals(expectedPonuda, actualPonuda);
    }

    @Test
    void canObrisiPonudu() {
        // Given
        long idPonuda = 1L;
        // When
        service.obrisiPonudu(idPonuda);
        // Then
        verify(ponudaRepo).deleteById(idPonuda);
    }

    @Test
    void canDohvatiAutoprijevoznike() {
        // Given
        List<Autoprijevoznik> expectedAutoprijevoznici = Collections.singletonList(new Autoprijevoznik());
        when(autoprijevoznikRepo.findAll()).thenReturn(expectedAutoprijevoznici);

        // When
        List<Autoprijevoznik> actualAutoprijevoznici = service.dohvatiAutoprijevoznike();

        // Then
        verify(autoprijevoznikRepo).findAll();
        assertEquals(expectedAutoprijevoznici, actualAutoprijevoznici);
    }

    @Test
    void canAzurirajVozilo() {
        // Given
        Vozilo azuriranoVozilo = new Vozilo();
        azuriranoVozilo.setIdVozilo(1L);
        azuriranoVozilo.setRegTablica("Tablica1");
        azuriranoVozilo.setBrojMjesta(50);
        azuriranoVozilo.setTipVozila("Tip1");

        when(voziloRepo.findByRegTablica(anyString())).thenReturn(Optional.empty());
        when(voziloRepo.save(any(Vozilo.class))).thenReturn(new Vozilo());

        // When
        service.azurirajVozilo(azuriranoVozilo);

        // Then
        verify(voziloRepo).save(any(Vozilo.class));
    }


    @Test
    public void testStvoriAutoprijevoznika_NewAutoprijevoznik() {

        NoviAutoprijevoznikDTO dto = new NoviAutoprijevoznikDTO();
        dto.setAutoprijevoznik("Autoprijevoznik 2");
        List<Vozilo> vozila = new ArrayList<>();
        vozila.add(new Vozilo("456", 30, "Minibus"));
        dto.setVozila(vozila);

        when(autoprijevoznikRepo.findByNaziv(anyString())).thenReturn(Optional.empty());

        service.stvoriAutoprijevoznika(dto);

        verify(autoprijevoznikRepo, times(1)).save(any());
        verify(voziloRepo, times(1)).findByRegTablica(anyString());
        verify(voziloRepo, times(1)).save(any());
    }

    @Test
    public void testStvoriAutoprijevoznika_ExistingAutoprijevoznik() {
        NoviAutoprijevoznikDTO dto = new NoviAutoprijevoznikDTO();
        dto.setAutoprijevoznik("Autoprijevoznik 1");
        List<Vozilo> vozila = new ArrayList<>();
        vozila.add(new Vozilo("123", 50, "Bus"));
        dto.setVozila(vozila);

        when(autoprijevoznikRepo.findByNaziv(anyString())).thenReturn(Optional.of(new Autoprijevoznik()));

        assertThrows(RequestDeniedException.class, () -> service.stvoriAutoprijevoznika(dto));

        verify(autoprijevoznikRepo, never()).save(any());
        verify(voziloRepo, never()).findByRegTablica(anyString());
        verify(voziloRepo, never()).save(any());
    }


    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
