package planput.a_controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.OverrideAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import planput.a_controller.DTO.AzuriranaPonudaDTO;
import planput.a_controller.DTO.KartaDTO;
import planput.a_controller.DTO.NovaPonudaDTO;
import planput.a_controller.DTO.RezervacijaDTO;
import planput.b_service.CRUDService;
import planput.b_service.RequestDeniedException;
import planput.d_domain.*;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(CRUDController.class)
public class ControllerUnitTests {
    @Autowired
    private MockMvc mvc;

    @MockBean
    private CRUDService crudService;

    @Test
    public void stvoriPonuduTest() throws Exception {
        NovaPonudaDTO dto = new NovaPonudaDTO(
                new Date(1), new Date(8), new Time(10_000_000), new Time(18_000_000),
                "Zagreb", "Split", 10,
                "Autoprijevoznik1", Arrays.asList("Tab1", "Tab2")
        );

        given(crudService.stvoriPonudu(dto)).willReturn(true);

        mvc.perform(post("/create").accept(MediaType.APPLICATION_JSON)
                        .content(asJsonString(dto))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));
    }

    @Test
    public void stvoriPonuduFailedTest() throws Exception {
        NovaPonudaDTO dto = new NovaPonudaDTO(
                new Date(1), new Date(8), new Time(18_000_000), new Time(10_000_000),
                "Zagreb", "Split", 10,
                "Autoprijevoznik1", Arrays.asList("Tab1", "Tab2")
        );

        given(crudService.stvoriPonudu(dto)).willThrow(RequestDeniedException.class);

        mvc.perform(post("/create").accept(MediaType.APPLICATION_JSON)
                        .content(asJsonString(dto))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void dohvatiPonuduTest() throws Exception {
        Vozilo vozilo1 = new Vozilo("ABC123", 30, "Autobus");
        vozilo1.setIdVozilo(1L);
        Vozilo vozilo2 = new Vozilo("DEF456", 40, "Autobus");
        vozilo1.setIdVozilo(2L);

        Autoprijevoznik autoprijevoznik = new Autoprijevoznik("Autoprijevoznik1", Arrays.asList(vozilo1,vozilo2));
        autoprijevoznik.setIdAutoprijevoznik(1L);

        Ponuda ponuda = new Ponuda(
                new Timestamp(10_000_000),
                new Timestamp(18_000_000),
                new Mjesto(10000, "Zagreb"),
                new Mjesto(21000, "Split"),
                100,
                autoprijevoznik,
                new ArrayList<>()
        );
        ponuda.setIdPonuda(1L);

        PonudaVozilo pv = new PonudaVozilo(ponuda, vozilo1);
        pv.setId(1L);
        ponuda.getVozila().add(pv);

        given(crudService.dohvatiPonudu(1L)).willReturn(ponuda);

        mvc.perform(get("/read/1").accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(
                        "{" +
                                "\"idPonuda\":1,"+
                                "\"vrijemePolaska\":\"1970-01-01T02:46:40.000+00:00\","+
                                "\"vrijemeDolaska\":\"1970-01-01T05:00:00.000+00:00\","+
                                "\"mjestoPolaska\":{\"pbr\":10000,\"naziv\":\"Zagreb\"},"+
                                "\"mjestoDolaska\":{\"pbr\":21000,\"naziv\":\"Split\"},"+
                                "\"cijena\":100.0,"+
                                "\"autoprijevoznik\":{"+
                                    "\"idAutoprijevoznik\":1,"+
                                    "\"naziv\":\"Autoprijevoznik1\","+
                                    "\"vozila\":["+
                                        "{\"idVozilo\":2,\"regTablica\":\"ABC123\",\"brojMjesta\":30,\"tipVozila\":\"Autobus\"},"+
                                        "{\"idVozilo\":null,\"regTablica\":\"DEF456\",\"brojMjesta\":40,\"tipVozila\":\"Autobus\"}"+
                                    "]"+
                                "},"+
                                "\"vozila\":["+
                                    "{\"id\":1,"+
                                        "\"idPonuda\":1,"+
                                        "\"vozilo\":{\"idVozilo\":2,\"regTablica\":\"ABC123\",\"brojMjesta\":30,\"tipVozila\":\"Autobus\"},\"brojKarata\":30"+
                                    "}"+
                                "]"+
                        "}"));
    }

    @Test
    public void azurirajPonuduTest() throws Exception {
        AzuriranaPonudaDTO dto = new AzuriranaPonudaDTO(
                new Date(1), new Date(8), new Time(10_000_000), new Time(18_000_000),
                "Zagreb", "Split", 10, 1
        );

        given(crudService.azurirajPonudu(dto)).willReturn(true);

        mvc.perform(put("/update").accept(MediaType.APPLICATION_JSON)
                        .content(asJsonString(dto))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));
    }

    @Test
    public void azurirajPonuduFailedTest() throws Exception {
        AzuriranaPonudaDTO dto = new AzuriranaPonudaDTO(
                new Date(1), new Date(8), new Time(10_000_000), new Time(18_000_000),
                "Zagreb", "Split", 10, 1
        );

        given(crudService.azurirajPonudu(dto)).willThrow(RequestDeniedException.class);

        mvc.perform(put("/update").accept(MediaType.APPLICATION_JSON)
                        .content(asJsonString(dto))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    @Test
    public void rezervirajPonuduTest() throws Exception {
        List<KartaDTO> karte = Arrays.asList(
                new KartaDTO(1, "ABC123", "abc@gmail.com"),
                new KartaDTO(2, "ABC123", "abc@gmail.com"),
                new KartaDTO(3, "ABC123", "abc@gmail.com"),
                new KartaDTO(4, "DEF123", "abc@gmail.com"),
                new KartaDTO(5, "DEF123", "abc@gmail.com")
        );

        given(crudService.rezervirajPonudu(1, "abc@gmail.com", 10)).willReturn(karte);

        mvc.perform(post("/rezervacija").accept(MediaType.APPLICATION_JSON)
                        .content(asJsonString(new RezervacijaDTO(1, "abc@gmail.com", 10)))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string("["+
                        "{\"idKarta\":1,\"regTablice\":\"ABC123\",\"email\":\"abc@gmail.com\"},"+
                        "{\"idKarta\":2,\"regTablice\":\"ABC123\",\"email\":\"abc@gmail.com\"},"+
                        "{\"idKarta\":3,\"regTablice\":\"ABC123\",\"email\":\"abc@gmail.com\"},"+
                        "{\"idKarta\":4,\"regTablice\":\"DEF123\",\"email\":\"abc@gmail.com\"},"+
                        "{\"idKarta\":5,\"regTablice\":\"DEF123\",\"email\":\"abc@gmail.com\"}"
                +"]"));
    }

    @Test
    public void rezervirajPonuduFailedTest() throws Exception {
        given(crudService.rezervirajPonudu(1, "abc@gmail.com", 100)).willThrow(RequestDeniedException.class);

        mvc.perform(post("/rezervacija").accept(MediaType.APPLICATION_JSON)
                        .content(asJsonString(new RezervacijaDTO(1, "abc@gmail.com", 100)))
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest());
    }

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
