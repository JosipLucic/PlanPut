package planput.a_controller;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.Map;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class RestExceptionHandler {

	@ExceptionHandler({IllegalArgumentException.class})
	protected ResponseEntity<?> handleIllegalArgument(Exception e, WebRequest request) {
		Map<String, Object> props = new LinkedHashMap<>();
		props.put("timestamp", (new Timestamp(System.currentTimeMillis())).toString());
		props.put("status", 400);
		props.put("error", "Bad Request");
		props.put("message", e.getMessage());
		return new ResponseEntity<>(props, HttpStatus.BAD_REQUEST);
	}

}
