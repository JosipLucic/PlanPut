package planput.a_controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import planput.a_controller.DTO.*;
import planput.b_service.CRUDService;
import planput.d_domain.Autoprijevoznik;
import planput.d_domain.Ponuda;
import planput.d_domain.Vozilo;

import java.util.List;

@RestController
@RequestMapping("/")
public class CRUDController {
    @Autowired
    private CRUDService crudService;

    @PostMapping("/create")
    public boolean stvoriPonudu(@RequestBody NovaPonudaDTO dto) {
        return crudService.stvoriPonudu(dto);
    }

    @GetMapping("/read")
    public List<Ponuda> dohvatiPonude() {
        return crudService.dohvatiPonude();
    }

    @GetMapping("/read/{idPonuda}")
    public Ponuda dohvatiPonudu(@PathVariable("idPonuda") long idPonuda) {
        return crudService.dohvatiPonudu(idPonuda);
    }

    @PutMapping("/update")
    public boolean azurirajPonudu(@RequestBody AzuriranaPonudaDTO dto) {
        return crudService.azurirajPonudu(dto);
    }

    @DeleteMapping("/delete/{idPonuda}")
    public void obrisiPonudu(@PathVariable("idPonuda") long idPonuda) {
        crudService.obrisiPonudu(idPonuda);
    }

    @PostMapping("/rezervacija")
    public List<KartaDTO> rezervirajPonudu(@RequestBody RezervacijaDTO dto) {
        return crudService.rezervirajPonudu(dto.getIdPonuda(), dto.getEmail(), dto.getBrojKarata());
    }



    @PostMapping("/create/autoprijevoznik")
    public void stvoriAutoprijevoznika(@RequestBody NoviAutoprijevoznikDTO dto) {
        crudService.stvoriAutoprijevoznika(dto);
    }

    @GetMapping("/read/autoprijevoznik")
    public List<Autoprijevoznik> dohvatiAutoprijevoznike() {
        return crudService.dohvatiAutoprijevoznike();
    }

    @PutMapping("/update/vozilo")
    public void azurirajVozilo(@RequestBody Vozilo azuriranoVozilo) {
        crudService.azurirajVozilo(azuriranoVozilo);
    }

    @DeleteMapping("/delete/pv/{id}")
    public void obrisiPonudaVozilo(@PathVariable("id") long id) {
        crudService.obrisiPonudaVozilo(id);
    }
}
