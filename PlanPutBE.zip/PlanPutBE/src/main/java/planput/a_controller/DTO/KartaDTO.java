package planput.a_controller.DTO;

import planput.d_domain.Karta;

public class KartaDTO {
    private long idKarta;
    private String regTablice;
    private String email;

    public KartaDTO() {
    }

    public KartaDTO(long idKarta, String regTablice, String email) {
        this.idKarta = idKarta;
        this.regTablice = regTablice;
        this.email = email;
    }

    public KartaDTO(Karta karta) {
        this.idKarta = karta.getIdKarta();
        this.regTablice = karta.getPonudaVozilo().getVozilo().getRegTablica();
        this.email = karta.getEmail();
    }

    public long getIdKarta() {
        return idKarta;
    }

    public void setIdKarta(long idKarta) {
        this.idKarta = idKarta;
    }

    public String getRegTablice() {
        return regTablice;
    }

    public void setRegTablice(String regTablice) {
        this.regTablice = regTablice;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
