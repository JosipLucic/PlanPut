package planput.a_controller.DTO;

import java.sql.Time;
import java.util.Date;

public class AzuriranaPonudaDTO extends PonudaDTO{
    private long idPonuda;

    public AzuriranaPonudaDTO(long idPonuda) {
        super();
    }

    public AzuriranaPonudaDTO(Date datumPolaska, Date datumDolaska, Time vrijemePolaska, Time vrijemeDolaska, String mjestoPolaska, String mjestoDolaska, float cijena, long idPonuda) {
        super(datumPolaska, datumDolaska, vrijemePolaska, vrijemeDolaska, mjestoPolaska, mjestoDolaska, cijena);
        this.idPonuda = idPonuda;
    }

    public long getIdPonuda() {
        return idPonuda;
    }

    public void setIdPonuda(long idPonuda) {
        this.idPonuda = idPonuda;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AzuriranaPonudaDTO that)) return false;
        if (!super.equals(o)) return false;

        return getIdPonuda() == that.getIdPonuda();
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (int) (getIdPonuda() ^ (getIdPonuda() >>> 32));
        return result;
    }
}
