package planput.a_controller.DTO;

import planput.d_domain.Vozilo;

import java.util.List;

public class NoviAutoprijevoznikDTO {
    private String autoprijevoznik;
    private List<Vozilo> vozila;

    public String getAutoprijevoznik() {
        return autoprijevoznik;
    }

    public void setAutoprijevoznik(String autoprijevoznik) {
        this.autoprijevoznik = autoprijevoznik;
    }

    public List<Vozilo> getVozila() {
        return vozila;
    }

    public void setVozila(List<Vozilo> vozila) {
        this.vozila = vozila;
    }
}
