package planput.a_controller.DTO;

import java.sql.Time;
import java.util.Date;

public class PonudaDTO {
    private Date datumPolaska;
    private Date datumDolaska;
    private Time vrijemePolaska;
    private Time vrijemeDolaska;
    private String mjestoPolaska;
    private String mjestoDolaska;
    private float cijena;

    public PonudaDTO() {
    }

    public PonudaDTO(Date datumPolaska, Date datumDolaska, Time vrijemePolaska, Time vrijemeDolaska, String mjestoPolaska, String mjestoDolaska, float cijena) {
        this.datumPolaska = datumPolaska;
        this.datumDolaska = datumDolaska;
        this.vrijemePolaska = vrijemePolaska;
        this.vrijemeDolaska = vrijemeDolaska;
        this.mjestoPolaska = mjestoPolaska;
        this.mjestoDolaska = mjestoDolaska;
        this.cijena = cijena;
    }

    public Date getDatumPolaska() {
        return datumPolaska;
    }

    public void setDatumPolaska(Date datumPolaska) {
        this.datumPolaska = datumPolaska;
    }

    public Date getDatumDolaska() {
        return datumDolaska;
    }

    public void setDatumDolaska(Date datumDolaska) {
        this.datumDolaska = datumDolaska;
    }

    public Time getVrijemePolaska() {
        return vrijemePolaska;
    }

    public void setVrijemePolaska(Time vrijemePolaska) {
        this.vrijemePolaska = vrijemePolaska;
    }

    public Time getVrijemeDolaska() {
        return vrijemeDolaska;
    }

    public void setVrijemeDolaska(Time vrijemeDolaska) {
        this.vrijemeDolaska = vrijemeDolaska;
    }

    public String getMjestoPolaska() {
        return mjestoPolaska;
    }

    public void setMjestoPolaska(String mjestoPolaska) {
        this.mjestoPolaska = mjestoPolaska;
    }

    public String getMjestoDolaska() {
        return mjestoDolaska;
    }

    public void setMjestoDolaska(String mjestoDolaska) {
        this.mjestoDolaska = mjestoDolaska;
    }

    public float getCijena() {
        return cijena;
    }

    public void setCijena(float cijena) {
        this.cijena = cijena;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PonudaDTO ponudaDTO)) return false;

        if (Float.compare(ponudaDTO.getCijena(), getCijena()) != 0) return false;
        if (getDatumPolaska() != null ? !getDatumPolaska().equals(ponudaDTO.getDatumPolaska()) : ponudaDTO.getDatumPolaska() != null)
            return false;
        if (getDatumDolaska() != null ? !getDatumDolaska().equals(ponudaDTO.getDatumDolaska()) : ponudaDTO.getDatumDolaska() != null)
            return false;
        if (getVrijemePolaska() != null ? !getVrijemePolaska().equals(ponudaDTO.getVrijemePolaska()) : ponudaDTO.getVrijemePolaska() != null)
            return false;
        if (getVrijemeDolaska() != null ? !getVrijemeDolaska().equals(ponudaDTO.getVrijemeDolaska()) : ponudaDTO.getVrijemeDolaska() != null)
            return false;
        if (getMjestoPolaska() != null ? !getMjestoPolaska().equals(ponudaDTO.getMjestoPolaska()) : ponudaDTO.getMjestoPolaska() != null)
            return false;
        return getMjestoDolaska() != null ? getMjestoDolaska().equals(ponudaDTO.getMjestoDolaska()) : ponudaDTO.getMjestoDolaska() == null;
    }

    @Override
    public int hashCode() {
        int result = getDatumPolaska() != null ? getDatumPolaska().hashCode() : 0;
        result = 31 * result + (getDatumDolaska() != null ? getDatumDolaska().hashCode() : 0);
        result = 31 * result + (getVrijemePolaska() != null ? getVrijemePolaska().hashCode() : 0);
        result = 31 * result + (getVrijemeDolaska() != null ? getVrijemeDolaska().hashCode() : 0);
        result = 31 * result + (getMjestoPolaska() != null ? getMjestoPolaska().hashCode() : 0);
        result = 31 * result + (getMjestoDolaska() != null ? getMjestoDolaska().hashCode() : 0);
        result = 31 * result + (getCijena() != +0.0f ? Float.floatToIntBits(getCijena()) : 0);
        return result;
    }
}
