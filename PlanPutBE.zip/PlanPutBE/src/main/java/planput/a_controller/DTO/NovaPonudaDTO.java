package planput.a_controller.DTO;

import java.sql.Time;
import java.util.Date;
import java.util.List;

public class NovaPonudaDTO extends PonudaDTO {
    private String autoprijevoznik;
    private List<String> regTablice;

    public NovaPonudaDTO() {
    }

    public NovaPonudaDTO(Date datumPolaska, Date datumDolaska, Time vrijemePolaska, Time vrijemeDolaska, String mjestoPolaska, String mjestoDolaska, float cijena, String autoprijevoznik, List<String> regTablice) {
        super(datumPolaska, datumDolaska, vrijemePolaska, vrijemeDolaska, mjestoPolaska, mjestoDolaska, cijena);
        this.autoprijevoznik = autoprijevoznik;
        this.regTablice = regTablice;
    }

    public String getAutoprijevoznik() {
        return autoprijevoznik;
    }

    public void setAutoprijevoznik(String autoprijevoznik) {
        this.autoprijevoznik = autoprijevoznik;
    }

    public List<String> getRegTablice() {
        return regTablice;
    }

    public void setRegTablice(List<String> regTablice) {
        this.regTablice = regTablice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof NovaPonudaDTO that)) return false;
        if (!super.equals(o)) return false;

        if (getAutoprijevoznik() != null ? !getAutoprijevoznik().equals(that.getAutoprijevoznik()) : that.getAutoprijevoznik() != null)
            return false;
        return getRegTablice() != null ? getRegTablice().equals(that.getRegTablice()) : that.getRegTablice() == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (getAutoprijevoznik() != null ? getAutoprijevoznik().hashCode() : 0);
        result = 31 * result + (getRegTablice() != null ? getRegTablice().hashCode() : 0);
        return result;
    }
}
