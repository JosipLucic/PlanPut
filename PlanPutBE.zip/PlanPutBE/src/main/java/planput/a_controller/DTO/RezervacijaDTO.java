package planput.a_controller.DTO;

public class RezervacijaDTO {
    private long idPonuda;
    private String email;
    private int brojKarata;

    public RezervacijaDTO() {
    }

    public RezervacijaDTO(long idPonuda, String email, int brojKarata) {
        this.idPonuda = idPonuda;
        this.email = email;
        this.brojKarata = brojKarata;
    }

    public long getIdPonuda() {
        return idPonuda;
    }

    public void setIdPonuda(long idPonuda) {
        this.idPonuda = idPonuda;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getBrojKarata() {
        return brojKarata;
    }

    public void setBrojKarata(int brojKarata) {
        this.brojKarata = brojKarata;
    }
}
