package planput.a_controller.DTO;

public class VoziloDTO {
    private String regTablica;
    private int brojMjesta;
    private String tipVozila;

    public String getRegTablica() {
        return regTablica;
    }

    public void setRegTablica(String regTablica) {
        this.regTablica = regTablica;
    }

    public int getBrojMjesta() {
        return brojMjesta;
    }

    public void setBrojMjesta(int brojMjesta) {
        this.brojMjesta = brojMjesta;
    }

    public String getTipVozila() {
        return tipVozila;
    }

    public void setTipVozila(String tipVozila) {
        this.tipVozila = tipVozila;
    }
}
