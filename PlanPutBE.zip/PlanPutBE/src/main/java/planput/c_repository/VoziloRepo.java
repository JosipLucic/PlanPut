package planput.c_repository;

import org.springframework.data.jpa.repository.JpaRepository;
import planput.d_domain.Vozilo;

import java.util.Optional;

public interface VoziloRepo extends JpaRepository<Vozilo, Long> {
    Optional<Vozilo> findByRegTablica(String regTablica);
}
