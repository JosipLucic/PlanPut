package planput.c_repository;

import org.springframework.data.jpa.repository.JpaRepository;
import planput.d_domain.Karta;

public interface KartaRepo extends JpaRepository<Karta, Long> {
}
