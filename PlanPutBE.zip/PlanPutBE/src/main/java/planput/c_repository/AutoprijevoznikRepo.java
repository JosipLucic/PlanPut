package planput.c_repository;

import org.springframework.data.jpa.repository.JpaRepository;
import planput.d_domain.Autoprijevoznik;

import java.util.Optional;

public interface AutoprijevoznikRepo extends JpaRepository<Autoprijevoznik, Long> {
    Optional<Autoprijevoznik> findByNaziv(String naziv);
}
