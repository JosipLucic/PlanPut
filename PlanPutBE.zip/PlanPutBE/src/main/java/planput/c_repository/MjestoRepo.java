package planput.c_repository;

import org.springframework.data.jpa.repository.JpaRepository;
import planput.d_domain.Mjesto;

import java.util.Optional;

public interface MjestoRepo extends JpaRepository<Mjesto, Integer> {
    Optional<Mjesto> findByNaziv(String naziv);
}
