package planput.c_repository;

import org.springframework.data.jpa.repository.JpaRepository;
import planput.d_domain.PonudaVozilo;

public interface PonudaVoziloRepo extends JpaRepository<PonudaVozilo, Long> {
    long countByIdPonuda(long id);
    void deleteByIdPonudaIsNull();
}
