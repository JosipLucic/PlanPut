package planput.c_repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import planput.d_domain.Ponuda;

import java.sql.Timestamp;
import java.util.List;

public interface PonudaRepo extends JpaRepository<Ponuda, Long> {

    @Modifying
    @Query("SELECT p FROM Ponuda p WHERE p.vrijemePolaska > ?1 ORDER BY p.vrijemePolaska ASC")
    List<Ponuda> findDostupne(Timestamp trenutnoVrijeme);
}
