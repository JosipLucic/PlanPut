package planput.d_domain;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;

@Entity
@Table(name = "Karta")
public class Karta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idKarta")
    private Long idKarta;

    @ManyToOne
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "idPonudaVozilo")
    private PonudaVozilo ponudaVozilo;

    @Column(name = "email", length = 30, nullable = false)
    private String email;

    public Karta() {}

    public Karta(PonudaVozilo ponudaVozilo, String email) {
        this.ponudaVozilo = ponudaVozilo;
        this.email = email;
    }

    public Long getIdKarta() {
        return idKarta;
    }

    public void setIdKarta(Long idKarta) {
        this.idKarta = idKarta;
    }

    public PonudaVozilo getPonudaVozilo() {
        return ponudaVozilo;
    }

    public void setPonudaVozilo(PonudaVozilo ponudaVozilo) {
        this.ponudaVozilo = ponudaVozilo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "Karta{" +
                "idKarta=" + idKarta +
                ", ponudaVozilo=" + ponudaVozilo +
                ", email='" + email + '\'' +
                '}';
    }
}
