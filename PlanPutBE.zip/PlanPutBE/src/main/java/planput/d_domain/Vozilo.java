package planput.d_domain;

import javax.persistence.*;

@Entity
@Table(name = "Vozilo")
@Inheritance(strategy = InheritanceType.JOINED)
public class Vozilo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idVozilo")
    private Long idVozilo;

    @Column(name = "regTablica", length = 20, unique = true)
    private String regTablica;

    @Column(name = "brojMjesta")
    private int brojMjesta;

    @Column(name = "tipVozila", length = 40)
    private String tipVozila;

    public Vozilo() {}

    public Vozilo(String regTablica, int brojMjesta, String tipVozila) {
        this.regTablica = regTablica;
        this.brojMjesta = brojMjesta;
        this.tipVozila = tipVozila;
    }

    public Long getIdVozilo() {
        return idVozilo;
    }

    public void setIdVozilo(Long idVozilo) {
        this.idVozilo = idVozilo;
    }

    public String getRegTablica() {
        return regTablica;
    }

    public void setRegTablica(String regTablica) {
        this.regTablica = regTablica;
    }

    public int getBrojMjesta() {
        return brojMjesta;
    }

    public void setBrojMjesta(int brojMjesta) {
        this.brojMjesta = brojMjesta;
    }

    public String getTipVozila() {
        return tipVozila;
    }

    public void setTipVozila(String tipVozila) {
        this.tipVozila = tipVozila;
    }

    @Override
    public String toString() {
        return "Vozilo{" +
                "idVozilo=" + idVozilo +
                ", regTablica='" + regTablica + '\'' +
                ", brojMjesta=" + brojMjesta +
                ", tipVozila='" + tipVozila + '\'' +
                '}';
    }
}
