package planput.d_domain;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Autoprijevoznik")
public class Autoprijevoznik {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idAutoprijevoznik")
    private Long idAutoprijevoznik ;

    @Column(name = "naziv", length = 30, nullable = false, unique = true)
    private String naziv;

    @OneToMany(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "idAutoprijevoznik")
    private List<Vozilo> vozila;

    public Autoprijevoznik() {}

    public Autoprijevoznik(String naziv, List<Vozilo> vozila) {
        this.naziv = naziv;
        this.vozila = vozila;
    }

    public Long getIdAutoprijevoznik() {
        return idAutoprijevoznik;
    }

    public void setIdAutoprijevoznik(Long idAutoprijevoznik) {
        this.idAutoprijevoznik = idAutoprijevoznik;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public List<Vozilo> getVozila() {
        return vozila;
    }

    public void setVozila(List<Vozilo> vozila) {
        this.vozila = vozila;
    }

    @Override
    public String toString() {
        return "Autoprijevoznik{" +
                "idAutoprijevoznik=" + idAutoprijevoznik +
                ", naziv='" + naziv + '\'' +
                ", vozila=" + vozila +
                '}';
    }
}
