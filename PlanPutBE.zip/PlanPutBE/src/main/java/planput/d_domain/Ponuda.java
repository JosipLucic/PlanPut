package planput.d_domain;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Entity
@Table(name = "Ponuda")
public class Ponuda {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idPonuda")
    private Long idPonuda;

    @Column(name = "vrijemePolaska", nullable = false)
    private Timestamp vrijemePolaska;

    @Column(name = "vrijemeDolaska", nullable = false)
    private Timestamp vrijemeDolaska;

    @ManyToOne
    @JoinColumn(name = "mjestoPolaska")
    private Mjesto mjestoPolaska;

    @ManyToOne
    @JoinColumn(name = "mjestoDolaska")
    private Mjesto mjestoDolaska;

    @Column(name = "cijena", nullable = false)
    private float cijena;

    @ManyToOne
    @JoinColumn(name = "idAutoprijevoznik")
    private Autoprijevoznik autoprijevoznik;

    @OneToMany(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "idPonuda")
    private List<PonudaVozilo> vozila;

    public Ponuda() {}

    public Ponuda(Timestamp vrijemePolaska, Timestamp vrijemeDolaska, Mjesto mjestoPolaska, Mjesto mjestoDolaska, float cijena, Autoprijevoznik autoprijevoznik, List<PonudaVozilo> vozila) {
        this.vrijemePolaska = vrijemePolaska;
        this.vrijemeDolaska = vrijemeDolaska;
        this.mjestoPolaska = mjestoPolaska;
        this.mjestoDolaska = mjestoDolaska;
        this.cijena = cijena;
        this.autoprijevoznik = autoprijevoznik;
        this.vozila = vozila;
    }

    public Long getIdPonuda() {
        return idPonuda;
    }

    public void setIdPonuda(Long idPonuda) {
        this.idPonuda = idPonuda;
    }

    public Timestamp getVrijemePolaska() {
        return vrijemePolaska;
    }

    public void setVrijemePolaska(Timestamp vrijemePolaska) {
        this.vrijemePolaska = vrijemePolaska;
    }

    public Timestamp getVrijemeDolaska() {
        return vrijemeDolaska;
    }

    public void setVrijemeDolaska(Timestamp vrijemeDolaska) {
        this.vrijemeDolaska = vrijemeDolaska;
    }

    public Mjesto getMjestoPolaska() {
        return mjestoPolaska;
    }

    public void setMjestoPolaska(Mjesto mjestoPolaska) {
        this.mjestoPolaska = mjestoPolaska;
    }

    public Mjesto getMjestoDolaska() {
        return mjestoDolaska;
    }

    public void setMjestoDolaska(Mjesto mjestoDolaska) {
        this.mjestoDolaska = mjestoDolaska;
    }

    public float getCijena() {
        return cijena;
    }

    public void setCijena(float cijena) {
        this.cijena = cijena;
    }

    public Autoprijevoznik getAutoprijevoznik() {
        return autoprijevoznik;
    }

    public void setAutoprijevoznik(Autoprijevoznik autoprijevoznik) {
        this.autoprijevoznik = autoprijevoznik;
    }

    public List<PonudaVozilo> getVozila() {
        return vozila;
    }

    public void setVozila(List<PonudaVozilo> vozila) {
        this.vozila = vozila;
    }

    @Override
    public String toString() {
        return "Ponuda{" +
                "idPonuda=" + idPonuda +
                ", vrijemePolaska=" + vrijemePolaska +
                ", vrijemeDolaska=" + vrijemeDolaska +
                ", mjestoPolaska=" + mjestoPolaska +
                ", mjestoDolaska=" + mjestoDolaska +
                ", cijena=" + cijena +
                ", autoprijevoznik=" + autoprijevoznik +
                ", vozila=" + vozila +
                '}';
    }
}
