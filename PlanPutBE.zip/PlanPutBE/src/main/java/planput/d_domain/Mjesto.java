package planput.d_domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Mjesto")
public class Mjesto {

    @Id
    @Column(name = "pbr")
    private Integer pbr;

    @Column(name = "naziv", length = 30, nullable = false, unique = true)
    private String naziv;

    public Mjesto() {}

    public Mjesto(Integer pbr, String naziv) {
        this.pbr = pbr;
        this.naziv = naziv;
    }

    public Integer getPbr() {
        return pbr;
    }

    public void setPbr(Integer pbr) {
        this.pbr = pbr;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    @Override
    public String toString() {
        return "Mjesto{" +
                "pbr=" + pbr +
                ", naziv='" + naziv + '\'' +
                '}';
    }
}
