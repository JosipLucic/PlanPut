package planput.d_domain;

import javax.persistence.*;

@Entity
@Table(name = "PonudaVozilo", uniqueConstraints = { @UniqueConstraint(columnNames = { "idPonuda", "idVozilo" }) })
public class PonudaVozilo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "idPonuda")
    private Long idPonuda;

    @ManyToOne
    @JoinColumn(name = "idVozilo")
    private Vozilo vozilo;

    @Column(name = "brojKarata")
    private int brojKarata;

    public PonudaVozilo() {}

    public PonudaVozilo(Ponuda ponuda, Vozilo vozilo) {
        this.idPonuda = ponuda.getIdPonuda();
        this.vozilo = vozilo;
        this.brojKarata = vozilo.getBrojMjesta();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public long getIdPonuda() {
        return idPonuda;
    }

    public void setIdPonuda(long idPonuda) {
        this.idPonuda = idPonuda;
    }

    public Vozilo getVozilo() {
        return vozilo;
    }

    public void setVozilo(Vozilo vozilo) {
        this.vozilo = vozilo;
    }

    public int getBrojKarata() {
        return brojKarata;
    }

    public void setBrojKarata(int brojKarata) {
        this.brojKarata = brojKarata;
    }

    @Override
    public String toString() {
        return "PonudaVozilo{" +
                "id=" + id +
                ", idPonuda=" + idPonuda +
                ", vozilo=" + vozilo +
                ", brojKarata=" + brojKarata +
                '}';
    }
}
