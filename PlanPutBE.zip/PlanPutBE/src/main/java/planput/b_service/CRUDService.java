package planput.b_service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import planput.a_controller.DTO.*;
import planput.c_repository.*;
import planput.d_domain.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CRUDService {
    @Autowired
    private MjestoRepo mjestoRepo;
    @Autowired
    private PonudaRepo ponudaRepo;
    @Autowired
    private VoziloRepo voziloRepo;
    @Autowired
    private AutoprijevoznikRepo autoprijevoznikRepo;
    @Autowired
    private PonudaVoziloRepo pvRepo;
    @Autowired
    private KartaRepo kartaRepo;

    public boolean stvoriPonudu(NovaPonudaDTO dto) {
        ValidiranaPonuda vp = new ValidiranaPonuda(dto);

        Ponuda novaPonuda = ponudaRepo.save(new Ponuda(
                vp.vrijemePolaska,
                vp.vrijemeDolaska,
                vp.mjestoPolaska,
                vp.mjestoDolaska,
                vp.cijena,
                autoprijevoznikRepo.findByNaziv(dto.getAutoprijevoznik()).orElseThrow(),
                new ArrayList<>()
        ));

        dto.getRegTablice().stream()
                .map(regTablica -> voziloRepo.findByRegTablica(regTablica).orElseThrow())
                .map(vozilo -> new PonudaVozilo(novaPonuda, vozilo))
                .forEach(ponudaVozilo -> pvRepo.save(ponudaVozilo));

        return true;
    }

    public List<Ponuda> dohvatiPonude() {
        return ponudaRepo.findDostupne(new Timestamp(System.currentTimeMillis()));
    }

    public Ponuda dohvatiPonudu(long idPonuda) {
        return ponudaRepo.findById(idPonuda).get();
    }

    public boolean azurirajPonudu(AzuriranaPonudaDTO dto) {
        ValidiranaPonuda vp = new ValidiranaPonuda(dto);

        Ponuda ponuda = ponudaRepo.findById(dto.getIdPonuda()).orElseThrow();
        ponuda.setVrijemePolaska(vp.vrijemePolaska);
        ponuda.setVrijemeDolaska(vp.vrijemeDolaska);
        ponuda.setMjestoPolaska(vp.mjestoPolaska);
        ponuda.setMjestoDolaska(vp.mjestoDolaska);
        ponuda.setCijena(vp.cijena);
        ponudaRepo.save(ponuda);

        return true;
    }

    public void obrisiPonudu(long idPonuda) {
        ponudaRepo.deleteById(idPonuda);
    }

    public List<KartaDTO> rezervirajPonudu(long idPonuda, String email, int brojKarata) {
        Ponuda ponuda = ponudaRepo.findById(idPonuda).orElseThrow();
        List<PonudaVozilo> pvLista = ponuda.getVozila().stream().sorted((pv1, pv2) -> {
            int n1 = pv1.getBrojKarata();
            int n2 = pv2.getBrojKarata();

            if (n1 != n2) {
                return Integer.compare(n1,n2);
            }

            String regTablice1 = pv1.getVozilo().getRegTablica();
            String regTablice2 = pv2.getVozilo().getRegTablica();

            return regTablice1.compareTo(regTablice2);
        }).toList();

        int brojSlobodnihMjesta = pvLista.stream().mapToInt(pv -> pv.getBrojKarata()).sum();
        if (brojSlobodnihMjesta < brojKarata) {
            throw new RequestDeniedException("Broj zatrazenih karata je veci od broja dostupnih: " + brojSlobodnihMjesta);
        }

        List<KartaDTO> karte = new ArrayList<>();
        for (PonudaVozilo pv : pvLista) {
            while (pv.getBrojKarata() > 0 && brojKarata > 0) {
                pv.setBrojKarata(pv.getBrojKarata() - 1);
                brojKarata--;

                karte.add(new KartaDTO(kartaRepo.save(new Karta(pv, email))));
            }

            pvRepo.save(pv);
        }

        return karte;
    }



    public void stvoriAutoprijevoznika(NoviAutoprijevoznikDTO dto) {
        if (autoprijevoznikRepo.findByNaziv(dto.getAutoprijevoznik()).isPresent())
            throw new RequestDeniedException(
                    String.format("Autoprijevoznik s nazivom \"%s\" vec postoji", dto.getAutoprijevoznik()));

        List<Vozilo> vozila = dto.getVozila().stream()
                .peek(v -> {
                    if (v.getBrojMjesta() <= 0)
                        throw new RequestDeniedException(
                                "Svako vozilo mora imati barem 1 sjedalo.");
                    if (voziloRepo.findByRegTablica(v.getRegTablica()).isPresent())
                        throw new RequestDeniedException(
                                String.format("Vozilo s registracijskim tablicama \"%s\" vec koristi drugi autoprijevoznik", v.getRegTablica()));
                })
                .map(v -> voziloRepo.save(new Vozilo(v.getRegTablica(), v.getBrojMjesta(), v.getTipVozila())))
                .toList();

        Autoprijevoznik autoprijevoznik = autoprijevoznikRepo.save(
                new Autoprijevoznik(dto.getAutoprijevoznik(), vozila));
    }

    public List<Autoprijevoznik> dohvatiAutoprijevoznike() {
        return autoprijevoznikRepo.findAll();
    }

    public void azurirajVozilo(Vozilo azuriranoVozilo) {
        Optional<Vozilo> vozilo2 = voziloRepo.findByRegTablica(azuriranoVozilo.getRegTablica());

        if (vozilo2.isPresent() && (long) vozilo2.get().getIdVozilo() != azuriranoVozilo.getIdVozilo())
            throw new RequestDeniedException(
                    String.format("Vec postoji drugo vozilo s tablicama \"%s\".", azuriranoVozilo.getRegTablica()));

        voziloRepo.save(azuriranoVozilo);
    }

    public void obrisiPonudaVozilo(long id) {
        PonudaVozilo ponudaVozilo = pvRepo.findById(id).orElseThrow();
        if (pvRepo.countByIdPonuda(ponudaVozilo.getIdPonuda()) == 1) {
            throw new RequestDeniedException("Ponuda mora raspolagati barem jednim vozilom.");
        }

        pvRepo.deleteById(id);
    }



    private class ValidiranaPonuda {
        private final Timestamp vrijemePolaska;
        private final Timestamp vrijemeDolaska;
        private final Mjesto mjestoPolaska;
        private final Mjesto mjestoDolaska;
        private final float cijena;

        public ValidiranaPonuda(PonudaDTO dto) {
            if (dto.getMjestoPolaska().equals(dto.getMjestoDolaska()))
                throw new RequestDeniedException("Mjesto polaska i dolaska moraju biti razliciti.");

            Timestamp vrijemePolaska = new Timestamp(dto.getDatumPolaska().getTime() + dto.getVrijemePolaska().getTime());
            Timestamp vrijemeDolaska = new Timestamp(dto.getDatumDolaska().getTime() + dto.getVrijemeDolaska().getTime());
            if (vrijemePolaska.getTime() >= vrijemeDolaska.getTime())
                throw new RequestDeniedException("Dolazak je naveden prije polaska.");

            Optional<Mjesto> mjestoPolaska = mjestoRepo.findByNaziv(dto.getMjestoPolaska());
            if (mjestoPolaska.isEmpty())
                throw new RequestDeniedException("Mjesto polaska je krivo napisano ili nije dostupno u bazi podataka.");

            Optional<Mjesto> mjestoDolaska = mjestoRepo.findByNaziv(dto.getMjestoDolaska());
            if (mjestoDolaska.isEmpty())
                throw new RequestDeniedException("Mjesto dolaska je krivo napisano ili nije dostupno u bazi podataka.");

            if (dto.getCijena() < 0)
                throw new RequestDeniedException("Cijena ne smije biti negativna.");

            this.vrijemePolaska = vrijemePolaska;
            this.vrijemeDolaska = vrijemeDolaska;
            this.mjestoPolaska = mjestoPolaska.get();
            this.mjestoDolaska = mjestoDolaska.get();
            this.cijena = dto.getCijena();
        }

    }
}
