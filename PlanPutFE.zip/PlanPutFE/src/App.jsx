import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Homepage from './Pages/Homepage';
import Detailpage from './Pages/Detailpage';
import Editpage from './Pages/Editpage';
import './App.css';

function App() {
    return (
        <Router>
            <div>
                <Routes>
                    <Route path="/" element={<Homepage />} />
                    <Route path="/details/:idPonuda" element={<Detailpage />} />
                    <Route path="/edit/:idPonuda" element={<Editpage />} />
                </Routes>
            </div>
        </Router>
    );
}

export default App;

