import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import "./Editpage.css";
import axios from "axios";

function Editpage() {
    const { idPonuda } = useParams();
    const [offer, setOffer] = useState(null);
    const [allVehicles, setAllVehicles] = useState([]);
    const [isEditingOffer, setIsEditingOffer] = useState(false);
    const [editedOffer, setEditedOffer] = useState({
        mjestoPolaska: '',
        mjestoDolaska: '',
        datumPolaska: '',
        datumDolaska: '',
        vrijemePolaska: '',
        vrijemeDolaska: '',
        cijena: ''
    });
    const [currentlyEditingVehicleId, setCurrentlyEditingVehicleId] = useState(null);
    const [editedVehicle, setEditedVehicle] = useState({
        tipVozila: '',
        regTablica: '',
        brojMjesta: ''
    });

    const idPonudaInt = parseInt(idPonuda);

    console.log("ispisuiiii id", idPonudaInt)

    const fetchData = async () => {
        try {
            console.log('Fetching data for idPonuda:', idPonuda); // Dodano za praćenje
            const response = await fetch('http://localhost:8080/read/' + idPonuda, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
    
            if (response.ok) {
                const offer = await response.json();
                console.log('Podaci uspješno dohvaćeni.', offer);
                setOffer(offer); 
            } else {
                console.error('Došlo je do greške prilikom dohvaćanja podataka.', response.status);
                alert('Došlo je do greške prilikom dohvaćanja podataka.');
            }
        } catch (error) {
            console.error('Greška:', error);
            alert('Došlo je do greške prilikom dohvaćanja podataka.');
        }
    };

    useEffect(() => {
        fetchData();
    }, [idPonuda]);

    console.log("ponuda jeeee", offer);

    const handleEditClick = () => {
        if (offer) {
            setEditedOffer({
                mjestoPolaska: offer.mjestoPolaska.naziv,
                mjestoDolaska: offer.mjestoDolaska.naziv,
                datumPolaska: offer.datumPolaska,
                datumDolaska: offer.datumDolaska,
                vrijemePolaska: offer.vrijemePolaska,
                vrijemeDolaska: offer.vrijemeDolaska,
                cijena: offer.cijena
            });
            setIsEditingOffer(true);
        }
    };

    const handleEditVehicleClick = (pv) => {
        setEditedVehicle(pv.vozilo);
        setCurrentlyEditingVehicleId(pv.vozilo.regTablica);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEditedOffer({ ...editedOffer, [name]: value });
    };

    const handleVehicleChange = (e) => {
        const { name, value } = e.target;
        setEditedVehicle({ ...editedVehicle, [name]: value });
    };

    const handleSave = async () => {
        try {
            const offerToSave = { ...editedOffer, idPonuda: idPonudaInt };
            console.log(JSON.stringify(offerToSave));
            const response = await fetch('http://localhost:8080/update', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(offerToSave),
            });

            if (response.ok) {
                setOffer(editedOffer);
                setIsEditingOffer(false);
                window.location.reload(true);
            } else {
                const data = await response.json();
                console.error('Greska:', data.message);
                alert('Neuspjesno uredivanje: ' + data.message);
            }
        } catch (error) {
            console.error('Došlo je do pogreške:', error);
        }
    };

    const handleSaveVehicle = async () => {
        try {
            console.log(JSON.stringify(editedVehicle));
            const response = await fetch('http://localhost:8080/update/vozilo', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(editedVehicle),
            });

            if (response.ok) {
                const updatedVehicles = offer?.vozila.map(pv =>
                    pv.vozilo.regTablica === editedVehicle.regTablica ? editedVehicle : pv.vozilo
                );
                setAllVehicles(updatedVehicles);
                setCurrentlyEditingVehicleId(null);
                window.location.reload(true);
            } else {
                console.error('Greška prilikom spremanja vozila');
            }
        } catch (error) {
            console.error('Došlo je do pogreške:', error);
        }
    };

    const handleCancel = () => {
        setEditedOffer({
            mjestoPolaska: offer?.mjestoPolaska.naziv || '',
            mjestoDolaska: offer?.mjestoDolaska.naziv || '',
            datumPolaska: offer?.vrijemePolaska.substring(8,10)-offer?.vrijemePolaska.substring(5,8)-offer?.vrijemePolaska.substring(0,4) || '',
            datumDolaska: offer?.vrijemeDolaska.substring(8,10)-offer?.vrijemeDolaska.substring(5,8)-offer?.vrijemeDolaska.substring(0,4) || '',
            vrijemePolaska: offer?.vrijemePolaska.substring(11,19) || '',
            vrijemeDolaska: offer?.vrijemeDolaska || '',
            cijena: offer?.cijena || ''
        });
        setIsEditingOffer(false);
    };

    const handleCancelVehicle = () => {
        setCurrentlyEditingVehicleId(null);
    };

    const deleteVehicle = (id) => {
        axios.delete(`http://localhost:8080/delete/pv/${id}`)
            .then(res => {
                if (res.status === 200) {
                    window.location.reload(true);
                } else {
                    console.log(res);
                    alert("Neuspješno brisanje: " + res.data.message);
                }
            })
            .catch(error => {
                console.log(error);
                alert("Neuspješno brisanje: " + (error.response ? error.response.data.message : error.message));
            });
    };

    return (
        <>
            <div className="header2">
                <h1>Uredi ponudu</h1>
            </div>

            {isEditingOffer ? (
                <div className="detail">
                    <h2>ID Ponude: {idPonudaInt}</h2>
                    <p>
                        Mjesto polaska:
                        <input
                            className="input2"
                            type="text"
                            name="mjestoPolaska"
                            value={editedOffer.mjestoPolaska}
                            onChange={handleChange}
                            required
                        />
                    </p>
                    <p>
                        Mjesto dolaska:
                        <input
                            className="input2"
                            type="text"
                            name="mjestoDolaska"
                            value={editedOffer.mjestoDolaska}
                            onChange={handleChange}
                            required
                        />
                    </p>
                    <p>
                        Datum polaska:
                        <input
                            className="input2"
                            type="date"
                            name="datumPolaska"
                            value={editedOffer.datumPolaska}
                            onChange={handleChange}
                            required
                        />
                    </p>
                    <p>
                        Vrijeme polaska:
                        <input
                            className="input2"
                            type="text"
                            name="vrijemePolaska"
                            value={null}
                            onChange={handleChange}
                            required
                        />
                    </p>
                    <p>
                        Datum dolaska:
                        <input
                            className="input2"
                            type="date"
                            name="datumDolaska"
                            value={editedOffer.datumDolaska}
                            onChange={handleChange}
                            required
                        />
                    </p>
                    <p>
                        Vrijeme dolaska:
                        <input
                            className="input2"
                            type="text"
                            name="vrijemeDolaska"
                            value={null}
                            onChange={handleChange}
                            required
                        />
                    </p>
                    <p>
                        Cijena:
                        <input
                            className="input2"
                            type="text"
                            name="cijena"
                            value={editedOffer.cijena}
                            onChange={handleChange}
                            required
                        />
                    </p>
                    <button className="buttonOptions" style={{ marginLeft: "7%" }} onClick={handleSave}>Spremi</button>
                    <button className="buttonOptions" onClick={handleCancel} style={{ padding: "1px 15px", marginLeft: "5%" }}>Odustani</button>
                </div>
            ) : (
                <div className="detail">
                    <h2>ID Ponude: {idPonudaInt}</h2>
                    <p>Mjesto polaska: {offer?.mjestoPolaska.naziv}</p>
                    <p>Mjesto dolaska: {offer?.mjestoDolaska.naziv}</p>
                    <p>Datum polaska: {offer?.vrijemePolaska.substring(8,10)}-{offer?.vrijemePolaska.substring(5,8)}{offer?.vrijemePolaska.substring(0,4)}</p>
                    <p>Vrijeme polaska: {offer?.vrijemePolaska.substring(11,19)} h</p>
                    <p>Datum dolaska: {offer?.vrijemeDolaska.substring(8,10)}-{offer?.vrijemeDolaska.substring(5,8)}{offer?.vrijemeDolaska.substring(0,4)}</p>
                    <p>Vrijeme dolaska: {offer?.vrijemeDolaska.substring(11,19)} h</p>
                    <p>Cijena: {offer?.cijena} €</p>
                    <button className="buttonOptions" style={{ marginLeft: "7%" }} onClick={handleEditClick}>Uredi</button>
                </div>
            )}

            <hr />
            <h1 className="detailTitle">
                Prijevoz:
            </h1>

            <table className="tripsTable2" style={{ marginLeft: "33%" }}>
                <thead>
                    <tr>
                        <th>Vrsta prijevoza</th>
                        <th>Registarske tablice</th>
                        <th>Broj sjedala</th>
                    </tr>
                </thead>
                <tbody>
                {offer?.vozila ? (
                        offer?.vozila.map((pv, index) => (
                        <tr key={index} style={{ backgroundColor: index % 2 === 0 ? '#f2f2f2' : 'white' }}>
                            {currentlyEditingVehicleId === pv.vozilo.regTablica ? (
                                <>
                                    <td style={{ padding: "25px 20px" }}>
                                        <input
                                            className="input"
                                            type="text"
                                            name="tipVozila"
                                            value={editedVehicle.tipVozila}
                                            onChange={handleVehicleChange}
                                            required
                                        />
                                    </td>
                                    <td style={{ padding: "35px 40px" }}>
                                        <input
                                            className="input"
                                            type="text"
                                            name="regTablica"
                                            value={editedVehicle.regTablica}
                                            onChange={handleVehicleChange}
                                            required
                                        />
                                    </td>
                                    <td style={{ padding: "25px 17px" }}>
                                        <input
                                            className="input"
                                            type="text"
                                            name="brojMjesta"
                                            value={editedVehicle.brojMjesta}
                                            onChange={handleVehicleChange}
                                            required
                                        />
                                    </td>
                                    <td style={{ display: 'flex', marginTop: "22%", marginRight: "10%" }}>
                                        <button className="buttonOptions" onClick={handleSaveVehicle}>Spremi</button>
                                        <button className="buttonOptions" onClick={handleCancelVehicle} style={{ padding: "1px 1px", marginLeft: "5%" }}>Odustani</button>
</td>
                                </>
                            ) : (
                                <>
                                    <td style={{ padding: "35px 45px" }}>{pv.vozilo.tipVozila}</td>
                                    <td style={{ padding: "35px 55px" }}>{pv.vozilo.regTablica}</td>
                                    <td style={{ padding: "35px 65px" }}>{pv.vozilo.brojMjesta}</td>
                                    <td>
                                        <button className="buttonOptions2" onClick={() => handleEditVehicleClick(pv)}>Uredi</button>
                                        <button className="buttonOptions2" style={{ padding: "1px 15px", marginRight: "15px" }} onClick={() => deleteVehicle(pv.id)}>Izbrisi</button>
                                    </td>
                                </>
                            )}
                        </tr>
                    ))
                ) : (
                    <tr>
                        <td colSpan="3">Nema dostupnih podataka o vozilima.</td>
                    </tr>
                )}
                </tbody>
            </table>


            <div className="footer">
                <p>Copyright 2024.</p>
            </div>
        </>
    );
}

export default Editpage;
