import { useState, useEffect } from 'react';
import "./Homepage.css";
import { Link } from 'react-router-dom';
import axios from "axios";

function Homepage() {
    const today = new Date().toISOString().split('T')[0];

    const [mjestoPolaska, setmjestoPolaska] = useState('');
    const [mjestoDolaska, setmjestoDolaska] = useState('');
    const [datumPolaska, setdatumPolaska] = useState(today);
    const [datumDolaska, setdatumDolaska] = useState(today);
    const [allTrips, setAllTrips] = useState([]);
    const [filteredTrips, setFilteredTrips] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [filteredVehicles, setFilteredVehicles] = useState([]); 
    const tripsPerPage = 10;

    const [showForm, setShowForm] = useState(false);
    const [showCarrierForm, setShowCarrierForm] = useState(false);
    const [newOffer, setNewOffer] = useState({
        mjestoPolaska: '',
        mjestoDolaska: '',
        datumPolaska: '',
        datumDolaska: '',
        vrijemePolaska: '',
        vrijemeDolaska: '',
        cijena: '',
        autoprijevoznik: '',
        regTablice: []
    });


    const [allVehicles, setAllVehicles] = useState([]);
    const [selectedregTablice, setSelectedregTablice] = useState([]);

    const [newCarrier, setNewCarrier] = useState({
        autoprijevoznik: '',
        vozila: [{ regTablica: '', brojMjesta: '', tipVozila: 'Autobus' }]
    });

    const [showReservationForm, setShowReservationForm] = useState(false);
    const [reservationDetails, setReservationDetails] = useState({
        email: '',
        brojKarata: '',
        idPonuda: ''
    });

    const [reservationResponse, setReservationResponse] = useState(null);

    const fetchData = async () => {
        try {
            const response = await fetch('http://localhost:8080/read', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
    
            if (response.ok) {
                const allTrips = await response.json();
                console.log('Podaci uspješno dohvaćeni:', allTrips);
                setAllTrips(allTrips); 
                setFilteredTrips(allTrips);
            } else {
                alert('Došlo je do greške prilikom dohvaćanja podataka.');
            }
        } catch (error) {
            console.error('Greška:', error);
            alert('Došlo je do greške prilikom dohvaćanja podataka.');
        }
    };

    useEffect(() => {
        fetchData();
    }, []);


    const fetchData2 = async () => {
        try {
            const response = await fetch('http://localhost:8080/read/autoprijevoznik', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
    
            if (response.ok) {
                const allVehicles = await response.json();
                console.log('Podaci uspješno dohvaćeni:', allVehicles);
                setAllVehicles(allVehicles); 
            } else {
                alert('Došlo je do greške prilikom dohvaćanja podataka.');
            }
        } catch (error) {
            console.error('Greška:', error);
            alert('Došlo je do greške prilikom dohvaćanja podataka.');
        }
    };

    useEffect(() => {
        fetchData2();
    }, []);


    const deleteTrip = (idPonuda) => {
        axios.delete(`http://localhost:8080/delete/${idPonuda}`).then(res => {

          window.location.reload(true);
        });
      }


    const reserveOffer = (idPonuda) => {
        setShowReservationForm(true);
        setReservationDetails(prevDetails => ({ ...prevDetails, idPonuda }));
    };

    const handleReservationChange = (e) => {
        const { name, value } = e.target;
        setReservationDetails(prevDetails => ({ ...prevDetails, [name]: value }));
    };


    const submitReservation = async () => {
        if (reservationDetails.email && reservationDetails.brojKarata) {
            try {
                console.log(JSON.stringify(reservationDetails));
                const response = await fetch('http://localhost:8080/rezervacija', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(reservationDetails),
                });

                if (response.ok) {
                    const data = await response.json();
                    console.log('Karte uspješno rezervirane', data);
                    setReservationResponse(data); 
                    setShowReservationForm(false);
                } else {
                    const data = await response.json();
                    console.error('Greska:', data.message);
                    alert('Nemoguća rezervacija. ' + data.message);
                }
            } catch (error) {
                alert('Doslo je do greske prilikom rezervacije.');
            }
        } else {
            alert('Molimo ispunite sva polja za rezervaciju.');
        }
    };



    const handleSearch = () => {
        if (mjestoPolaska && mjestoDolaska && datumPolaska && datumDolaska) {
            const filtered = allTrips.filter(trip => {
                trip.datumPolaska = `${trip.vrijemePolaska.substring(0,4)}-${trip.vrijemePolaska.substring(5,7)}-${trip.vrijemePolaska.substring(8,10)}`;
                trip.datumDolaska = `${trip.vrijemeDolaska.substring(0,4)}-${trip.vrijemeDolaska.substring(5,7)}-${trip.vrijemeDolaska.substring(8,10)}`;
                return (
                    trip.mjestoPolaska.naziv.toLowerCase().includes(mjestoPolaska.toLowerCase()) &&
                    trip.mjestoDolaska.naziv.toLowerCase().includes(mjestoDolaska.toLowerCase()) &&
                    trip.datumPolaska >= datumPolaska &&
                    trip.datumDolaska <= datumDolaska
                );
            });
            setFilteredTrips(filtered);
            setCurrentPage(1);
    
            console.log("Mjesto polaska:", mjestoPolaska);
            console.log("Mjesto dolaska:", mjestoDolaska);
            console.log("Datum odlaska:", datumPolaska);
            console.log("Datum dolaska:", datumDolaska);
    
        } else {
            alert("Molimo ispunite sva polja.");
            console.log("Mjesto polaska:", mjestoPolaska);
            console.log("Mjesto dolaska:", mjestoDolaska);
            console.log("Datum odlaska:", datumPolaska);
            console.log("Datum dolaska:", datumDolaska);
        }
    };
    
    



    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const offerWithSelectedPlates = { ...newOffer, regTablice: selectedregTablice };
            console.log(JSON.stringify(offerWithSelectedPlates));
            const response = await fetch('http://localhost:8080/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(offerWithSelectedPlates),
            });

            if (response.ok) {
                alert('Ponuda je uspjesno dodana!');
                setShowForm(false);
                window.location.reload(true);
            } else {
                alert('Doslo je do greske prilikom dodavanja ponude.');
            }
        } catch (error) {
            console.error('Greska:', error);
            alert('Doslo je do greske prilikom dodavanja ponude.');
        }
    };

    const handleCarrierSubmit = async (e) => {
        e.preventDefault();

        try {
            console.log(JSON.stringify(newCarrier));
            const response = await fetch('http://localhost:8080/create/autoprijevoznik', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(newCarrier),
            });

            if (response.ok) {
                alert('Autoprijevoznik je uspjesno dodan!');
                setShowCarrierForm(false);
                resetCarrierForm();
            } else {
                const data = await response.json();
                console.error('Greska:', data.message);
                alert('Nemoguće dodavanje vozila. ' + data.message);
            }
        } catch (error) {
            console.error('Greska:', error);
            alert('Doslo je do greske prilikom dodavanja autoprijevoznika.');
        }
    };

    const resetCarrierForm = () => {
        setNewCarrier({
            autoprijevoznik: '',
            vozila: [{ regTablica: '', brojMjesta: '', tipVozila: 'Autobus' }]
        });
    };

    const addVehicle = () => {
        setNewCarrier(prevCarrier => ({
            ...prevCarrier,
            vozila: [...prevCarrier.vozila, { regTablica: '', brojMjesta: '', tipVozila: 'Autobus' }]
        }));
    };

    const handleVehicleChange = (index, field, value) => {
        const updatedVehicles = [...newCarrier.vozila];
        updatedVehicles[index][field] = value;
        setNewCarrier(prevCarrier => ({ ...prevCarrier, vozila: updatedVehicles }));
    };


    console.log(allVehicles)

    const handleCheckboxChange = (e) => {
        const { value, checked } = e.target;
        setSelectedregTablice(prevSelected => {
            if (checked) {
                if (!prevSelected.includes(value)) {
                    return [...prevSelected, value];
                } else {
                    return prevSelected; 
                }
            } else {
                return prevSelected.filter(plate => plate !== value);
            }
        });
    };
    

    useEffect(() => {
        setNewOffer(prevOffer => ({
            ...prevOffer,
            regTablice: selectedregTablice
        }));
    }, [selectedregTablice]);

    const handleAutoprijevoznikChange = (e) => {
        const selectedAutoprijevoznik = e.target.value;
        setNewOffer({ ...newOffer, autoprijevoznik: selectedAutoprijevoznik });

        const filtered = allVehicles
            .filter(pv => pv.naziv === selectedAutoprijevoznik)
            .flatMap(pv => pv.vozila.map(v => v.regTablica));
        setFilteredVehicles(filtered);
        
    };


    const indexOfLastTrip = currentPage * tripsPerPage;
    const indexOfFirstTrip = indexOfLastTrip - tripsPerPage;
    const currentTrips = filteredTrips.slice(indexOfFirstTrip, indexOfLastTrip);

    const paginate = (pageNumber) => setCurrentPage(pageNumber);



    return (
        <>
            <div className={`overlay ${showForm || showReservationForm || reservationResponse || showCarrierForm ? 'show' : ''}`}></div>
            <div className="header">
                <input
                    style={{ marginLeft: "5%" }}
                    type="text"
                    placeholder="Mjesto polaska"
                    value={mjestoPolaska}
                    onChange={(e) => setmjestoPolaska(e.target.value)} 
                />

                <input
                    style={{ marginLeft: "-15%" }}
                    type="text"
                    placeholder="Mjesto dolaska"
                    value={mjestoDolaska}
                    onChange={(e) => setmjestoDolaska(e.target.value)} 
                />
                <p style={{ marginLeft: "-16%" }}>Datum odlaska: </p>
                <input
                    style={{ marginLeft: "-19%" }}
                    type="date"
                    value={datumPolaska}
                    min={today}
                    onChange={(e) => setdatumPolaska(e.target.value)}
                />
                <p style={{ marginLeft: "-17%" }}>Datum dolaska: </p>
                <input
                    style={{ marginLeft: "-19%" }}
                    type="date"
                    value={datumDolaska}
                    min={today}
                    onChange={(e) => setdatumDolaska(e.target.value)}
                />
                <button className="buttonSearch" onClick={handleSearch}>Trazi</button>
            </div>

            <h1 className="title">Ponude!</h1>
            <div>
                <table className="tripsTable0">
                    <thead>
                        <tr>
                            <th>Mjesto polaska</th>                          
                            <th>Mjesto dolaska</th>
                            <th>Datum polaska</th>
                            <th>Vrijeme polaska</th>
                            <th>Datum dolaska</th>
                            <th style={{ padding: "25px 40px" }}>Autoprijevoznik</th>
                            <th>Cijena</th>
                        </tr>
                    </thead>
                </table>
                <hr />
                <table className="tripsTable">
                    <tbody>
                        {currentTrips.map((trip, index) => (
                            <tr key={index} style={{ backgroundColor: index % 2 === 0 ? '#f2f2f2' : 'white' }}>
                                <td>{trip.mjestoPolaska.naziv}</td>
                                <td style={{ padding: "35px 45px" }}>{trip.mjestoDolaska.naziv}</td>
                                <td style={{ padding: "40px 70px" }}>{trip.vrijemePolaska.substring(8,10)}-{trip.vrijemePolaska.substring(5,8)}{trip.vrijemePolaska.substring(0,4)}</td>
                                <td style={{ padding: "35px 35px" }}>{trip.vrijemePolaska.substring(11,19)}</td>
                                <td style={{ padding: "35px 75px" }}>{trip.vrijemeDolaska.substring(8,10)}-{trip.vrijemeDolaska.substring(5,8)}{trip.vrijemeDolaska.substring(0,4)}</td>
                                <td style={{ padding: "40px 45px" }}>{trip.autoprijevoznik.naziv}</td>
                                <td style={{ padding: "40px 60px" }}>{trip.cijena} €</td>
                                <td>
                                    <Link to={`/details/${trip.idPonuda}`}>Detalji</Link>
                                    <button className="buttonOptions" style={{ marginLeft: "20px" }} onClick={() => reserveOffer(trip.idPonuda)}>Rezerviraj</button>
                                    <Link style={{ marginLeft: "20px" }} to={`/edit/${trip.idPonuda}`}>Uredi</Link>
                                    <button className="buttonOptions" style={{ marginLeft: "20px" }}  onClick={() => deleteTrip(trip.idPonuda)}>Obrisi</button>
                                    
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <div className="pagination">
                    {[...Array(Math.ceil(filteredTrips.length / tripsPerPage)).keys()].map(number => (
                        <button key={number + 1} onClick={() => paginate(number + 1)} className="buttonPage">
                            {number + 1}
                        </button>
                    ))}
                    <button className="buttonOptions3" style={{ marginLeft: "80px" }} onClick={() => setShowForm(true)}>Dodaj Ponudu</button>
                    <button className="buttonOptions3" style={{ marginLeft: "30px", width: "15%" }} onClick={() => setShowCarrierForm(true)} >Dodaj autoprijevoznika</button>
                </div>
                
            </div>

            {showForm && (
                <div className="popupForm">
                    <form onSubmit={handleSubmit}>
                        <h2>Dodaj Ponudu</h2>
                        <label>
                            Mjesto polaska:
                            <input
                                type="text"
                                name="mjestoPolaska"
                                value={newOffer.mjestoPolaska.naziv}
                                onChange={(e) => setNewOffer({ ...newOffer, mjestoPolaska: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Mjesto dolaska:
                            <input
                                type="text"
                                name="mjestoDolaska"
                                value={newOffer.mjestoDolaska.naziv}
                                onChange={(e) => setNewOffer({ ...newOffer, mjestoDolaska: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Datum polaska:
                            <input
                                type="date"
                                name="datumPolaska"
                                value={newOffer.datumPolaska}
                                onChange={(e) => setNewOffer({ ...newOffer, datumPolaska: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Vrijeme polaska:
                            <input
                                type="text"
                                name="vrijemePolaska"
                                value={newOffer.vrijemePolaska}
                                onChange={(e) => setNewOffer({ ...newOffer, vrijemePolaska: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Datum dolaska:
                            <input
                                type="date"
                                name="datumDolaska"
                                value={newOffer.datumDolaska}
                                onChange={(e) => setNewOffer({ ...newOffer, datumDolaska: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Vrijeme dolaska:
                            <input
                                type="text"
                                name="vrijemeDolaska"
                                value={newOffer.vrijemeDolaska}
                                onChange={(e) => setNewOffer({ ...newOffer, vrijemeDolaska: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Cijena:
                            <input
                                type="text"
                                name="cijena"
                                value={newOffer.cijena}
                                onChange={(e) => setNewOffer({ ...newOffer, cijena: e.target.value })}
                                required
                            />
                        </label>
                        <label>
                            Autoprijevoznik:
                            <select value={allVehicles.naziv} onChange={handleAutoprijevoznikChange} required>
                        <option value="">Odaberite autoprijevoznika</option>
                        {allVehicles.map((autoprijevoznik, index) => (
                            <option key={index} value={autoprijevoznik.naziv}>
                                {autoprijevoznik.naziv}
                            </option>
                        ))}
                    </select>
                        </label>
                        <div className="vehicle-checkboxes">
                            <p>Registarske tablice:</p>
                            {filteredVehicles.map((regTablica, index) => (
                                <label key={index}>
                                    <input
                                        type="checkbox"
                                        value={regTablica}
                                        checked={selectedregTablice.includes(regTablica)}
                                        onChange={handleCheckboxChange}
                                        required
                                    />
                                    {regTablica}
                                </label>
                    ))}
                    </div>
                        <button type="submit">Dodaj</button>
                        <button type="button" onClick={() => setShowForm(false)}>Zatvori</button>
                    </form>
                </div>
            )}


            {showCarrierForm && (
                <div className="popupForm">
                    <form onSubmit={handleCarrierSubmit} className="form-container">
                        <h2>Dodaj autoprijevoznika</h2>
                        <label>
                            Naziv autoprijevoznika:
                            <input type="text" value={newCarrier.autoprijevoznik.naziv} onChange={(e) => setNewCarrier({ ...newCarrier, autoprijevoznik: e.target.value })} required />
                        </label>
                        {newCarrier.vozila.map((vozilo, index) => (
                            <div key={index} className="vehicle-fields">
                                <label>
                                    Registarska tablica:
                                    <input type="text" value={vozilo.regTablica} onChange={(e) => handleVehicleChange(index, 'regTablica', e.target.value)} required />
                                </label>
                                <label>
                                    Broj sjedala:
                                    <input type="number" value={vozilo.brojMjesta} onChange={(e) => handleVehicleChange(index, 'brojMjesta', e.target.value)} min="1" required />
                                </label>
                                <label>
                                    Vrsta vozila:
                                    <select value={vozilo.tipVozila} onChange={(e) => handleVehicleChange(index, 'tipVozila', e.target.value)} required>
                                        <option value="Autobus">Autobus</option>
                                        <option value="Minibus">Minibus</option>
                                    </select>
                                </label>
                            </div>
                        ))}
                        <button style={{ width: "20%", marginLeft: "40%", backgroundColor: "blue" }} type="button" onClick={addVehicle}>Dodaj vozilo</button>
                        <button style={{ width: "50%", marginLeft: "25%" }} type="submit">Dodaj autoprijevoznika</button>
                        <button style={{ width: "50%", marginLeft: "25%" }} type="button" onClick={() => { setShowCarrierForm(false); resetCarrierForm(); }}>Odustani</button>
                    </form>
                </div>
            )}

            {showReservationForm && (
                <div className="popupForm">
                    <h2>Rezerviraj ponudu</h2>
                    <div >
                        <label>Broj karata:</label>
                        <input type="number" name="brojKarata" value={reservationDetails.brojKarata} onChange={handleReservationChange} min="1" />
                    </div>
                    <div >
                        <label>Email:</label>
                        <input type="email" name="email" value={reservationDetails.email} onChange={handleReservationChange} />
                    </div>
                    <button onClick={submitReservation}>Potvrdi rezervaciju</button>
                    <button style={{ marginLeft: "20px" }} onClick={() => setShowReservationForm(false)}>Odustani</button>
                </div>
            )}

            {reservationResponse && (
                <div className="popupForm" style={{ overflowY: 'auto', maxHeight: '80vh' }}>
                    {reservationResponse.map((rezervacija, index) => (
                        <div key={index}>
                            <h2>Rezervacija uspješna!</h2>
                            <p>Broj rezervacije: {rezervacija.idKarta}</p>
                            <p>Email: {rezervacija.email}</p>
                            <p>Vozilo: {rezervacija.regTablice}</p>
                        </div>
                    ))}
                    <button style={{ marginLeft: "80px" }} onClick={() => setReservationResponse(null)}>U redu</button>
                </div>
            )}




            <div className="footer">
                <p>Copyright 2024.</p>
            </div>

        </>
    );
}

export default Homepage;
