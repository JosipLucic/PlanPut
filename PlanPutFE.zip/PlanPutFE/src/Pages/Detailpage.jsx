import { Link } from 'react-router-dom';
import { useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import "./Detailpage.css";

function Detailpage() {
    const { idPonuda } = useParams();
    const [offer, setOffer] = useState(null);

    const fetchData = async () => {
        try {
            const response = await fetch('http://localhost:8080/read/' + idPonuda, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
    
            if (response.ok) {
                const offer = await response.json();
                console.log('Podaci uspješno dohvaćeni.');
                setOffer(offer); 
            } else {
                alert('Došlo je do greške prilikom dohvaćanja podataka.');
            }
        } catch (error) {
            console.error('Greška:', error);
            alert('Došlo je do greške prilikom dohvaćanja podataka.');
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    


    if (!offer) {
        return <div>Loading...</div>;
    }
    
    return (
        <>
            <div className="header">
                <h1>Detalji putovanja</h1>
            </div>

            <div className="detail">
                <h2>ID Ponude: {offer.idPonuda}</h2>
                <p>Mjesto polaska: {offer.mjestoPolaska.naziv}</p>
                <p>Mjesto dolaska: {offer.mjestoDolaska.naziv}</p>
                <p>Datum polaska: {offer.vrijemePolaska.substring(8,10)}-{offer.vrijemePolaska.substring(5,8)}{offer.vrijemePolaska.substring(0,4)}</p>
                <p>Vrijeme polaska: {offer.vrijemePolaska.substring(11,19)}</p>
                <p>Datum dolaska: {offer.vrijemeDolaska.substring(8,10)}-{offer.vrijemeDolaska.substring(5,8)}{offer.vrijemeDolaska.substring(0,4)}</p>
                <p>Vrijeme dolaska: {offer.vrijemeDolaska.substring(11,19)}</p>
                <p>Autoprijevoznik: {offer.autoprijevoznik.naziv}</p>
                <p>Cijena: {offer.cijena} €</p>
            </div>

            <hr />
            <h1 className="detailTitle">
                Prijevoz:
            </h1>

            <table className="tripsTable2" style={{ marginLeft: "33%" }}>
                <thead>
                    <tr>
                        <th>Vrsta prijevoza</th>
                        <th>Registarske tablice</th>
                        <th>Broj sjedala</th>
                    </tr>
                </thead>
            </table>
            <hr className="line" />
            <table className="tripsTable2">
            { <tbody>
                    {offer.vozila ? (
                        offer.vozila.map((pv, index) => (
                            <tr key={index} style={{ backgroundColor: index % 2 === 0 ? '#f2f2f2' : 'white' }}>
                                <td style={{ padding: "35px 45px" }}>{pv.vozilo.tipVozila}</td>
                                <td style={{ padding: "35px 65px" }}>{pv.vozilo.regTablica}</td>
                                <td style={{ padding: "35px 100px" }}>{pv.vozilo.brojMjesta}</td>
                            </tr>
                        ))
                    ) : (
                        <tr>
                            <td colSpan="3">Nema dostupnih podataka o vozilima.</td>
                        </tr>
                    )}
                </tbody> }
            </table>

            <div className="footer">
                <p>Copyright 2024.</p>
            </div>
        </>
    );
}

export default Detailpage;
